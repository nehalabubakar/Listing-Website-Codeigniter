<script type="text/javascript">
      jQuery(document).ready(function($) {
            $('.datatable').DataTable();
      });
</script>
